﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassWork
{
    internal class Student : IComparable<Student>
    {
        int Id { get; set; }
        string Name { get; set; }
        int Age { get; set; }

        public Student(int id, string name, int age)
        {
            this.Id = id;
            this.Name = name;
            this.Age = age; 
        }


        public override string ToString()
        {
            return $"[ Student Id: {Id} ,Name: {Name} ,Age: {Age} ]";
        }

        public int CompareTo(Student? other)
        {
            if(this.Id > other.Id)
            {
                return 1 ;
            }
            else
            {
                return -1 ;
            }
        }
    }
}
