﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassWork
{
    internal class ParamsInCsharp
    {
        static void Main2(string[] args)
        {
            int[] arr = new int[] { 1, 2, 3, 4, 5, 6 };
            AddAll(arr);

            string[] strings = new string[] { "Aditya", "Vijay", "Nikhate" };
            PrintString(strings);
        }

        public static void AddAll(params int[] num)
        {
            int sum = 0;
            for(int i=0; i < num.Length; i++)
            {
                sum += num[i];
            }
            Console.WriteLine($"The sum of numbers is: {sum}");
        }

        public static void PrintString(params string[] strings)
        {
            string resultString = "";
            for (int i = 0; i < strings.Length; i++)
            {
                resultString += strings[i]+" ";
            }
            Console.WriteLine(resultString);
        }
    }
}
