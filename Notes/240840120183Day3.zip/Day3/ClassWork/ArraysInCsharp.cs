﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassWork
{
    internal class ArraysInCsharp
    {
        static void Main5(string[] args)
        {
            //int[] arr = { 1, 2, 3, 4, 5, 5, 4, 8 };

            //for (int i = 0; i < arr.Length; i++) 
            //{ 
            //    Console.WriteLine(arr[i]);
            //}


            int[] arr1 = { 45, 87, 236, 12, 45, 2, 6, 1, 6, 45, 56, 54 };
            Array.Sort(arr1);
            for (int i = 0; i < arr1.Length; i++)
            {
                Console.WriteLine(arr1[i]);
            }

            Console.WriteLine(arr1.GetValue(1));
            Console.WriteLine(arr1.GetType());

            int ind = Array.IndexOf(arr1, 236);
            Console.WriteLine(ind);
        }

        static void Main6(string[] args)
        {
            //Student s = new Student(1, "Aditya", 22);
            //Console.WriteLine(s);
            int idGenerator = 100;
            Student[] students = new Student[3];
            for (int i = 0; i < students.Length; i++)
            {
                Console.Write("Enter your name: ");
                string name = Console.ReadLine();
                Console.Write("Enter your age: ");
                int age = (int) Console.Read();
                Console.WriteLine(age);
                Console.ReadLine();
                students[i] = new Student(idGenerator++, name, age);
            }
            Array.Sort(students);

            for (int i = 0; i < students.Length; i++) 
            {
                Console.WriteLine(students[i]);
            }
        }
    }
}
