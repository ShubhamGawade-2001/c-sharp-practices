﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassWork
{
    internal class Generic
    {
        static void Main3(string[] args)
        {
            Person<int, string> person = new Person<int, string>(45,"Aditya");
            person.Display();

            Emp<int, string, double> emp = new Emp<int, string, double>(6, "Hitesh", 456.23);
            emp.Display();
            
        }
    }

    
    class Person<T, M>
    {
        public T Id { get; set; }
        public M name { get; set; }

        public Person(T Id, M name)
        {
            this.Id = Id;
            this.name = name;
        }
        public virtual void Display()
        {
            Console.WriteLine($"Id {Id} name {name}");
        }
    }

    class Emp<T, M, N> : Person<T, M>
    {

        public N Basic { get; set; }
        public Emp(T Id, M name, N basic ):base(Id, name)
        {
            this.Basic = basic;
        }


        public override void Display()
        {
            base.Display();
            Console.WriteLine(this.Basic);
        }
    }
}
