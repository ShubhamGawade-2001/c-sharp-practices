﻿namespace ClassWork
{
    internal class Program
    {
        static void Main1(string[] args)
        {
            //Nullable
            int? a = 45;
            Console.WriteLine(a);
            a = null;
            int b = a??1;
            int c = a.GetValueOrDefault(4);
            Console.WriteLine(b);
            Console.WriteLine(c);

            if (a.HasValue)
            {
                Console.WriteLine(a.Value);
            }
            else
            {
                Console.WriteLine("A is null");
            }
        }
    }
}
