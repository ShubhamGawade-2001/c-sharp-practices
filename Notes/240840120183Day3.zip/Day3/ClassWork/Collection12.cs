﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassWork
{
    internal class Collection12
    {
        static void Main(string[] args)
        {
            LinkedList<Student> list = new LinkedList<Student>();
            

            list.AddFirst(new Student(4, "dsf", 23));
            list.AddFirst(new Student(1, "fdsf", 43));
            list.AddFirst(new Student(3, "ewrw", 63));
            list.AddFirst(new Student(2, "jvlkxj", 33));

            Console.WriteLine("Before Sort");
            foreach(Student student in list)
            {
                Console.WriteLine(student);
            }
            //list.Sort();

            Console.WriteLine("After Sort");
            foreach (Student student in list)
            {
                Console.WriteLine(student);
            }



        }
    }
}
