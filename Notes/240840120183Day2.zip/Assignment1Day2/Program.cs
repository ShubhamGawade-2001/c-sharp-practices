﻿using Employee;

namespace Assignment1Day2
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Manager Object: ");
            Manager manager = new Manager("Yash", 10,(decimal) 12233.0,"SDE");
            Console.WriteLine(manager);


            Console.WriteLine("CEO Object: ");
            CEO ceo = new CEO("Hitesh", 20, (decimal)80000000);
            Console.WriteLine("CEO Net Salary:  "+ceo.CalcNetSalary());
            Console.WriteLine(ceo);



            Console.WriteLine("GeneralManager Object: ");
            GeneralManager generalmanager = new GeneralManager("Lokesh",basic: (decimal)1000000);
            Console.WriteLine("GeneralManager Net Salary:  " + generalmanager.CalcNetSalary());
            Console.WriteLine(generalmanager);
        }
    }
}


namespace Employee
{
    internal abstract class Employee
    {
        private string name;
        private int empno;
        private short deptno;
        public abstract decimal Basic { get; set; }

        private static int empnogenerator = 100;

        public string Name
        {
            get { return name; }
            set
            {
                if(value == "")
                {
                    name = "unknown";
                }
                else
                {
                    name = value;
                }
            }
        }

        public short Deptno
        {
            get
            {
                return deptno;
            }
            set
            {
                if(value < 1)
                {
                    deptno = 1;
                }

                else
                {
                    deptno = value;
                }
            }
        }

        public int Empno
        {
            get { return empno; }
        }
        public Employee(string name="unknown", short deptno=1)
        {
            this.Name = name;
            this.Deptno = deptno;
            this.empno = empnogenerator++;
        }

        //abstract method 
        public abstract decimal CalcNetSalary();

        public override string ToString()
        {
            return "[ EmpNo: " + Empno + " Name: " + Name + " DeptNo: " + Deptno +" ]";
        }

    }


    class Manager : Employee
    {
        private decimal basic;
        private string designation;
        public override decimal Basic { 
            get => basic; 
            set  { basic = (value < 1) ? 1 : value; }
        }

        public string Designation
        {
            get { return designation; }
            set
            {
                if (value == "")
                {
                    designation = "HR";
                }
                else
                {
                    designation = value;
                }
            }
        }
        public Manager(string name="unknown", short deptno=1,  decimal basic=(decimal) 30562, string designation="HR") : base(name, deptno)
        {
            this.Designation = designation;
            this.Basic = basic;
        }

        public override decimal CalcNetSalary()
        {
            return  Basic * (decimal)(1.05);
        }

        public override string ToString()
        {
            return "[ EmpNo: " + Empno + " Name: " + Name + " DeptNo: " + Deptno + " Basic: "+Basic + " Designation: " + designation +" ]";
        }

    }

    class GeneralManager : Manager
    {
        public GeneralManager(string name = "unknown", short deptno = 1, decimal basic = (decimal)30562) : base(name, deptno, basic)
        {

        }

        public string Perks()
        {
            return "Goa Trip";
        }
        public string ToString()
        {
            return "[ EmpNo: " + Empno + " Name: " + Name + " DeptNo: " + Deptno + " Basic: " + Basic + " ]";
        }

    }



    class CEO : Employee
    {
        private decimal basic;
        public override decimal Basic {
            get => basic;
            set { basic = (value < 1) ? 1 : value; }
        }

        public CEO(string name = "unknown", short deptno = 1, decimal basic = (decimal)30562) : base(name, deptno)
        {
            this.Basic = basic;
        }

        public sealed override decimal CalcNetSalary()
        {
            return Basic * (decimal)(1.15);
        }

        public override string ToString()
        {
            return "[ EmpNo: " + Empno + " Name: " + Name + " DeptNo: " + Deptno + " Basic: " + Basic + " ]";
        }
    }
}