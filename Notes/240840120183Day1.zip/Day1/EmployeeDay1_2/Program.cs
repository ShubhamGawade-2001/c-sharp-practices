﻿namespace EmployeeDay1_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Employee employee = new Employee("Hitesh", 700000, 10);
            Console.WriteLine(employee);
            Console.WriteLine("Hitesh bhai ki salary: " + employee.getNetSalary());

            Employee employee1 = new Employee("Kunal", 800000, 20);
            Console.WriteLine(employee1);

            Console.WriteLine(employee1.Name1+" bhai ki salary: " + employee1.getNetSalary());

            Employee employee2 = new Employee("Yash", 1700000, 11);
            Console.WriteLine(employee2);
            Console.WriteLine(employee1.Name1 + " bhai ki salary: " + employee2.getNetSalary());

            Employee employee3 = new Employee("Bharat", 750000, 5);
            Console.WriteLine(employee3);
            Console.WriteLine(employee1.Name1 + " bhai ki salary: " + employee3.getNetSalary());

            Console.WriteLine(employee3.EmpNo);
        }
    }


    class Employee
    {
        private string name;
        private int empNo;
        private decimal basic;
        private short deptNo;
        private static int empNoGeneratory = 100;

        public short DeptNo
        {
            get
            {
                return deptNo;
            }

            set
            {
                if (value <= 0)
                {
                    deptNo = 0;
                }
                else
                {
                    deptNo = value;
                }
            }
        }

        public decimal Basic
        {
            get
            {
                return basic;
            }
            set
            {
                if (value <= (decimal)0.0)
                {
                    basic = 0;
                }
                else
                {
                    basic = (decimal)value;
                }
            }
        }

        public string Name1
        {
            get
            {
                return name;
            }
            set
            {
                if (value == "")
                {
                    name = "unknown";
                }
                else
                {
                    name = value;
                }
            }
        }


        public int EmpNo
        {
            get
            {
                return empNo;
            }
            
        }
        public Employee(string Name = "", decimal Basic = (decimal)0.0, short DeptNo = 0)
        {
            this.Name1 = Name;
            this.empNo = empNoGeneratory++;
            this.Basic = Basic;
            this.DeptNo = DeptNo;
        }

        public decimal getNetSalary()
        {
            return Basic * (decimal)0.95;
        }


        public override String ToString()
        {
            return "Name: " + name + " EmpNo: " + empNo + " Basic: " + basic + " DeptNo: " + deptNo;
        }

    }
}
