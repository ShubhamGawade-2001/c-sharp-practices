﻿namespace AssignmentDay1_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Employee employee = new Employee(1, "Hitesh", 700000, 10);
            Console.WriteLine(employee);
            Console.WriteLine("Hitesh bhai ki salary: " + employee.getNetSalary());
        }
    }


    class Employee
    {
        private string name;
        private int empNo;
        private decimal basic;
        private short deptNo;


        public short DeptNo
        {
            get
            {
                return deptNo;
            }

            set
            {
                if(value <= 0)
                {
                    deptNo = 0;
                }
                else
                {
                    deptNo = value;
                }
            }
        }

        public decimal Basic
        {
            get
            {
                return basic;
            }
            set
            {
                if(value <= (decimal)0.0)
                {
                    basic = 0;
                }
                else
                {
                    basic = (decimal) value;
                }
            }
        }

        public string Name1
        {
            get
            {
                return name;
            }
            set
            {
                if(value == "")
                {
                    name = "unknown";
                }
                else
                {
                    name = value;
                }
            }
        }


        public int EmpNo
        {
            get
            {
                return empNo;
            }
            set
            {
                if(value == 0)
                {
                    empNo = -1;
                }
                else
                {
                    empNo = value; 
                }
            }
        }
        public Employee(int EmpNo=0, string Name="", decimal Basic=(decimal) 0.0, short DeptNo=0)
        {
            this.Name1 = Name;
            this.EmpNo = EmpNo;
            this.Basic = Basic;
            this.DeptNo = DeptNo;
        }

        public decimal getNetSalary()
        {
            return Basic * (decimal)0.95;
        }


        public override String ToString()
        {
            return "Name: " + name + " EmpNo: " + empNo + " Basic: " + basic + " DeptNo: " + deptNo;
        }

    }
}
